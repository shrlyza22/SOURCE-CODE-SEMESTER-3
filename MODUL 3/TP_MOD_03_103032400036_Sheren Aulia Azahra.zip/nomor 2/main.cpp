#include <iostream>

using namespace std;

int main(){
    int masukan;

    masukan = 22;

    cout << "masukan: " << masukan << endl;
    cout << "alamat: " <<  &masukan << endl;
    return 0;
}
